//
// Created by Mateusz Ptak on 15/10/2022.
//

#ifndef LISTA1_EXERCISE3_H
#define LISTA1_EXERCISE3_H

bool bDeallocTable2Dim(int ***piTable, int iSizeX);

#endif //LISTA1_EXERCISE3_H
