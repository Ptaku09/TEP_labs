//
// Created by Mateusz Ptak on 14/10/2022.
//

#ifndef LISTA1_EXERCISE1_H
#define LISTA1_EXERCISE1_H

const int I_NUMBER_TO_FILL_ARRAY = 34;

void vAllocTableFill34(int iSize);

#endif //LISTA1_EXERCISE1_H
