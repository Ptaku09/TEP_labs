//
// Created by Mateusz Ptak on 15/10/2022.
//

#include <climits>
#include "Helpers.h"

bool bIsNumberPositive(int number) {
    return number > 0;
}

bool bIsNumberSmallerThenMaxInt(int number) {
    return number < INT_MAX;
}