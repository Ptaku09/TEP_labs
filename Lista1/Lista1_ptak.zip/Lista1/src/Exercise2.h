//
// Created by Mateusz Ptak on 15/10/2022.
//

#ifndef LISTA1_EXERCISE2_H
#define LISTA1_EXERCISE2_H

bool bAllocTable2Dim(int ***piTable, int iSizeX, int iSizeY);

#endif //LISTA1_EXERCISE2_H
