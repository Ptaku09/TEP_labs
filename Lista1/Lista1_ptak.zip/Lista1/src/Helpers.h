//
// Created by Mateusz Ptak on 15/10/2022.
//

#ifndef LISTA1_HELPERS_H
#define LISTA1_HELPERS_H

bool bIsNumberPositive(int number);

bool bIsNumberSmallerThenMaxInt(int number);

#endif //LISTA1_HELPERS_H
