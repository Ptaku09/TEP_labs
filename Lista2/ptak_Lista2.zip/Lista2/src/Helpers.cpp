//
// Created by Mateusz Ptak on 05/11/2022.
//

#include <climits>
#include "Helpers.h"

bool bIsNumberPositive(int number) {
    return number > 0;
}

bool bIsNumberSmallerThenMaxInt(int number) {
    return number < INT_MAX;
}
