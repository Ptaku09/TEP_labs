//
// Created by Mateusz Ptak on 05/11/2022.
//

#ifndef LISTA2_HELPERS_H
#define LISTA2_HELPERS_H

bool bIsNumberPositive(int number);

bool bIsNumberSmallerThenMaxInt(int number);

#endif //LISTA2_HELPERS_H